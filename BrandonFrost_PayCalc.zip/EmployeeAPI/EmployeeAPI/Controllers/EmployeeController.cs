﻿using EmployeeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EmployeeAPI.Controllers
{
    public class EmployeeController : ApiController
    {
        public IApplicationDbContext db;
        public EmployeeController()
            :base()
        {
            this.db = new ApplicationDbContext();
        }
        [HttpGet]
        public IEnumerable<Employee> GetEmployees()
        {
            return this.db.Employees;
        }
        [HttpPost]
        public Employee CreateEmployee(Employee Employee)
        {
            this.db.Employees.Add(Employee);
            db.SaveChanges();
            return Employee;
        }
        [HttpPut]
        public Employee UpdateEmployee(Employee Employee)
        {
            var entity = this.db.Employees.Find(Employee.EmployeeId);
            entity.FirstName = Employee.FirstName;
            entity.LastName = Employee.LastName;
            entity.Salary = Employee.Salary;
            entity.StartDate = Employee.StartDate;
            this.db.SaveChanges();
            return Employee;
        }
        [HttpDelete]
        public Employee DeleteEmployee(int Id)
        {
            var Employee = new Employee { EmployeeId = Id };
            this.db.Employees.Attach(Employee);
            this.db.Employees.Remove(Employee);
            this.db.SaveChanges();
            return Employee;
        }
    }
}
