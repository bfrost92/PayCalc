import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Employee } from '../Models/Employee'
import { EmployeeService } from '../Services/employee.service'
import { ToastsManager } from 'ng2-toastr/ng2-toastr'
import { ViewEncapsulation } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EmployeesComponent implements OnInit {

  public Employees:Array<Employee> = [
    new Employee({FirstName:"Brandon", LastName:"Frost", Salary:100000, Frequency:"Anually", HireDate:new Date()}),
    new Employee({FirstName:"John", LastName:"Wayne", Salary:100000, Frequency:"Anually", HireDate:new Date()}),
    new Employee({FirstName:"Bill", LastName:"Lumbergh", Salary:100000, Frequency:"Anually", HireDate:new Date()}),
    new Employee({FirstName:"Brandon", LastName:"Frost", Salary:100000, Frequency:"Anually", HireDate:new Date()}),
    new Employee({FirstName:"Brandon", LastName:"Frost", Salary:100000, Frequency:"Anually", HireDate:new Date()}),
  ];
  public FromDate:string;
  public ToDate:string;
  public CurrentEmployee = new Employee({});
  public display = true;
  public Mode:string;

  constructor(private EmployeeService:EmployeeService, private ToastsManager:ToastsManager, private ViewContainerRef:ViewContainerRef) { 
    ToastsManager.setRootViewContainerRef(ViewContainerRef)
  }

  ngOnInit() {
    this.Read();
  }

  public Read(){
    this.Employees = [];
    this.EmployeeService.GetEmployees().subscribe(res=>{
      for(let emp of res){
        emp.StartDate= new Date(emp.StartDate);
        console.log(emp.StartDate.getDate());
        this.Employees=this.Employees.concat(new Employee(emp));
      }
      console.log(this.Employees)
    });

  }
  public Create(){
    
    this.Mode="Create";
    this.CurrentEmployee = new Employee({});
    $("#MyModal").modal("show")
  }

  public Edit(Employee:Employee){
    this.Mode="Edit";
    this.CurrentEmployee = Employee;
    $("#MyModal").modal("show")
  }
  DeletePopup(Employee:Employee){
    this.CurrentEmployee = Employee;
    $("#DeleteModal").modal("show");
  }
  public Delete(){
    $("#DeleteModal").modal("hide");
    this.Employees = this.Employees.filter(f=>f.EmployeeId!=this.CurrentEmployee.EmployeeId);
    this.EmployeeService.DeleteEmployee(this.CurrentEmployee).subscribe(res=>{
      this.ToastsManager.success(this.CurrentEmployee.FirstName + " " + this.CurrentEmployee.LastName+ " was deleted successfully!");
    })
  }
  
  public CalcPay(){
    if(this.FromDate&&this.ToDate){
      var From = new Date(this.FromDate);
      var To = new Date(this.ToDate);
      var FromDay = From.getDay();
      var ToDay = To.getDay();
      var days = (Math.abs(From.getTime() - To.getTime()) / (1000*60*60*24))+1;
      var weeks = Math.floor(days/7);
      if(this.CurrentEmployee.Frequency.toLowerCase()=="hourly"){
        return 40*weeks*this.CurrentEmployee.Salary;
      }
      if(this.CurrentEmployee.Frequency.toLowerCase()=="biweekly"){
        return (this.CurrentEmployee.Salary/26)*Math.floor(weeks/2);
      }
      if(this.CurrentEmployee.Frequency.toLowerCase()=="monthly"){
        var months = (To.getFullYear() - From.getFullYear()) * 12;
        months -= From.getMonth() + 1;
        months += To.getMonth();
        return months*(this.CurrentEmployee.Salary/12);
        
        // var pay = (this.CurrentEmployee.Salary/12)*months;
        // if(pay<0){
        //   return 0;
        // }
        // return pay;
      }
    }
    return null
  }
  public EditSaveChanges(){
    this.EmployeeService.EditEmployee(this.CurrentEmployee).subscribe(res=>{
       this.ToastsManager.success(this.CurrentEmployee.FirstName + " " + this.CurrentEmployee.LastName+ " was updated successfully!");
      })
    $("#MyModal").modal("hide")
  }
  public CreateSaveChanges(){
    this.Employees = this.Employees.concat(this.CurrentEmployee);
    this.EmployeeService.CreateEmployee(this.CurrentEmployee).subscribe(res=>{
       this.ToastsManager.success(this.CurrentEmployee.FirstName + " " + this.CurrentEmployee.LastName+ " was created successfully!");
      })
    $("#MyModal").modal("hide")
    
  }

  

}
