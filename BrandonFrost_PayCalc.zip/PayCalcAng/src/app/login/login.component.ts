import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../Services/employee.service'
import { Router } from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(public EmployeeService:EmployeeService, public Router:Router) { }
  public user = {Email:'test@test.com', Password:'password'}
  ngOnInit() {
  }
  login(){
    this.EmployeeService.Login(this.user).subscribe(res=>{
      localStorage.setItem("token", res.access_token)
      this.Router.navigate(["dashboard"])
    },err=>{
      this.Router.navigate(["dashboard"]);
    });

  }
  Register(){
    this.Router.navigate(["register"]);
  }
}
