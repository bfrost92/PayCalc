import { Injectable } from '@angular/core';
import { Http, Headers, Request, RequestMethod, RequestOptions, URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


@Injectable()
export class EmployeeService {

  constructor(private http:Http) { }
  public Headers = new Headers({
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": localStorage.getItem("token")
  });
  public otherHeaders = new Headers({
            "Content-Type": "application/x-www-urlencoded",
            "Accept": "application/json",
  });
  public url:string="http://localhost:61194/api/";
  public authUrl:string="http://localhost:61194/token";
public GetEmployees(){
   var requestOptions = new RequestOptions({
        headers: this.Headers
        //body: { 'password': post.Password, 'username': post.UserName, 'grant_type': grant_type }
    });
      return this.http.get(this.url+"employee", requestOptions )
      .map(res => res.json())
      .map((res) => {
          if(res.status = 200) {
          }
          console.log(res)
          return res;
      })
}
public CreateEmployee(post:any){
   var requestOptions = new RequestOptions({
        headers: this.Headers
        //body: { 'password': post.Password, 'username': post.UserName, 'grant_type': grant_type }
    });
      return this.http.post(this.url+"employee", post, requestOptions )
      .map(res => res.json())
      .map((res) => {
          if(res.status = 200) {
          }
          console.log(res)
          return res;
      })
}
public EditEmployee(post:any){
   var requestOptions = new RequestOptions({
        headers: this.Headers
        //body: { 'password': post.Password, 'username': post.UserName, 'grant_type': grant_type }
    });
      return this.http.put(this.url+"employee", post,  requestOptions )
      .map(res => res.json())
      .map((res) => {
          if(res.status = 200) {
          }
          console.log(res)
          return res;
      })
}
public DeleteEmployee(post:any){
   var requestOptions = new RequestOptions({
        headers: this.Headers
        //body: { 'password': post.Password, 'username': post.UserName, 'grant_type': grant_type }
    });
      return this.http.delete(this.url+"Employee/"+post.EmployeeId, requestOptions )
      .map(res => res.json())
      .map((res) => {
          if(res.status = 200) {
          }
          console.log(res)
          return res;
      })
}
public Register(post:any){
   var requestOptions = new RequestOptions({
        headers: this.Headers
        //body: { 'password': post.Password, 'username': post.UserName, 'grant_type': grant_type }
    });
      return this.http.post(this.url+"Account/Register", post, requestOptions )
      .map(res => res.json())
      .map((res) => {
          if(res.status = 200) {
          }
          console.log(res)
          return res;
      })
}
public Login(post:any){
    console.log(post)
    var body = '';
        body +=  'username=' + post.Email + '&';
        body += 'password=' + post.Password + '&';
        body += 'grant_type=password';
    var requestOptions = new RequestOptions({
        headers: this.otherHeaders
        //body: { 'password': post.Password, 'username': post.UserName, 'grant_type': grant_type }
    });
      return this.http.post(this.authUrl, body,  requestOptions )
      .map(res => res.json())
      .map((res) => {
          if(res.status = 200) {
          }
          console.log(res)
          return res;
      })
}

}
