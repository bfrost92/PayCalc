export class Employee{
    EmployeeId:number;
    FirstName: string;
    LastName: string;
    Salary: number;
    StartDate: Date;
    Frequency: string;

    constructor(Employee:any){
        this.EmployeeId = Employee.EmployeeId;
        this.FirstName = Employee.FirstName;
        this.LastName = Employee.LastName;
        this.StartDate = Employee.StartDate;
        this.Salary = Employee.Salary;
        this.Frequency = Employee.Frequency;
    }
    


}