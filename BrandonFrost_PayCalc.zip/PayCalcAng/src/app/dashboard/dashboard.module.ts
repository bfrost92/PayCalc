import { NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import {DataTableModule, SharedModule} from 'primeng/primeng';
import { DashboardComponent } from './dashboard.component';
import { EmployeesComponent } from '../Employees/employees.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import {PaginatorModule} from 'primeng/primeng';
import {DialogModule} from 'primeng/primeng';
import {ConfirmDialogModule,ConfirmationService} from 'primeng/primeng';
import { CommonModule }       from '@angular/common';
import {CalendarModule} from 'primeng/primeng';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http'
import { EmployeeService } from '../Services/employee.service'
import {ToastModule} from 'ng2-toastr/ng2-toastr';

@NgModule({
  imports: [
    ToastModule.forRoot(),
    HttpModule,
    CalendarModule,
    DashboardRoutingModule,
    ChartsModule,
    DataTableModule,
    SharedModule,
    PaginatorModule,
    DialogModule,
    ConfirmDialogModule,
    CommonModule,
    FormsModule
    
  ],
  declarations: [ DashboardComponent, EmployeesComponent ],
  providers:[
    ConfirmationService,
    EmployeeService
  ],
})
export class DashboardModule { }
