import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router'
import { EmployeeService } from '../Services/employee.service'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  constructor(private EmployeeService:EmployeeService, public Router:Router) { }
  public user = {Email:"", Password:"", ConfirmPassword:"" }
  ngOnInit() {

  }
  public Register(){
    this.EmployeeService.Register(this.user).subscribe(res=>{
      
        this.Router.navigate(["login"])
    },
    err=>{
      console.log(err);
    })
  }

}
